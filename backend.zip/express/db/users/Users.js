const { DataTypes } = require("sequelize");

module.exports = function (sequelize) {
	return sequelize.define(		
		"users",
		{	
			id: {
				type: DataTypes.INTEGER.UNSIGNED,
				primaryKey: true,
			},
			username: {
				type: DataTypes.STRING(20),
				unique: true,
			},
			email: {
				type: DataTypes.STRING(20),
				unique: true,
			},
			password: {
				type: DataTypes.STRING(120),
			}
			// createdAt: {
			// 	type: DataTypes.DATE,
			// },
		},
		{
			timestamps: false,
			tableName: "users",
		}
	);
};
