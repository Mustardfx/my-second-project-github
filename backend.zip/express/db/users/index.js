const Sequelize = require("sequelize");
const sequelize = new Sequelize("test", "root", "", {
	dialect: "mysql",
	host: "localhost",
	logging: false,
});

const Users = require("./Users")(sequelize);
module.exports = {
	sequelize: sequelize,
	users: Users,
};