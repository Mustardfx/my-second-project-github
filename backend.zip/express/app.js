// Импортируем необходимые модули
const express = require("express");
const bodyParser = require("body-parser");
const authRouter = require("./src/routers/authRouter.js");
const app = express();
var cors = require('cors')
app.use(cors())

//ejs
app.set("view engine", "ejs");
app.set("views", __dirname + "/src/views");
app.get("/home", (req, res) => {
	res.render("index");
});

//api
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use("/api/auth", authRouter);	

//start server
app.listen(8080, () => console.log("Server running on port 8080"));
