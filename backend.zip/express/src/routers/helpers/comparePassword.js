const bcrypt = require("bcrypt");
const { users } = require("../../db/users");

async function comparePassword(plainPassword, username) {
	try {
		const user = await users.findOne({ where: { username } });
		// Сравниваем хэшированный пароль с введенным паролем
		const match = await bcrypt.compare(plainPassword, user.password);
		return match;
	} catch (error) {
		console.error("Error comparing passwords:", error);
		throw error;
	}
}

module.exports = comparePassword;
