const { users } = require("../../db/users");
const jwt = require("jsonwebtoken");
const hashPassword = require("../helpers/hashPassword");
const comparePassword = require("../helpers/comparePassword");

class authController {
	async registration(req, res) {
		try {
			const { username, password, email} = req.body;
			const hashedPassword = await hashPassword(password);

			const newUser = await users.create({
				username,
				password: hashedPassword,
				email
			});
			res
				.status(201)
				.json({ message: "User registered successfully", user: newUser });
		} catch (err) {
			console.error("Registration error:", err);
			res.status(400).json({ message: "Registration failed", error: err });
		}
	}
	async login(req, res) {
		try {

			const { username, password } = req.body;

			const user = await users.findOne({
				where: { username },
				attributes: { exclude: ["password"] },
			});

		
			if (!user) {
				return res.status(401).json({ message: "Invalid username" });
			}

			const isPasswordTrue = await comparePassword(password, username);
			if (!isPasswordTrue) {
				return res.status(401).json({ message: "Invalid password" });
			} else {
				const token = jwt.sign({ username: user.username }, "secret", {
					expiresIn: "1h",
				});
				res.status(200).json({ jwt: token, data: { user } });
			}
		} catch (err) {
			console.error(err);
			res.status(500).json({ message: "Internal server error", error: err });
		}
	}
	async getUsers(req, res) {
		try {
			const token = req.headers.authorization;

			if (!token) {
				return res.status(401).json({ message: "no token provided" });
			}
			const usersDB = await users.findAll({
				attributes: { exclude: ["password"] },
			});
			jwt.verify(token, "secret", (err) => {
				if (err) {
					return res.status(403).json({ message: "Forbidden" });
				} else {
					res.status(200).json({ data: usersDB });
				}
			});
		} catch (error) {
			res.status(500).json({ message: "error" });
		}
	}

	async getMe(req, res) {
		try {
			const token = req.headers.authorization;

			if (!token) {
				return res.status(401).json({ message: "no token provided" });
			}
			const usersDB = await users.findOne({
				attributes: { exclude: ["password"] },
			});
			jwt.verify(token, "secret", (err) => {
				if (err) {
					return res.status(403).json({ message: "Forbidden" });
				} else {
					res.status(200).json({ data: usersDB });
				}
			});
		} catch (error) {
			res.status(500).json({ message: "error" });
		}
	}
}

module.exports = new authController();
